from DeepDR import Data, Model, CellEncoder, DrugEncoder, FusionModule

cell_ft = Data.DrRead.FeatCell('cell_data.csv', subset=True, subset_path='gene_subset.txt')[0]
data = Data.DrData(Data.DrRead.PairCSV('response_data.csv'), cell_ft, 'Graph').clean()
train_data, val_data, _ = data.split('cell_out', fold=1, ratio=[0.8, 0.2, 0.0], seed=1)
train_loader = Data.DrDataLoader(Data.DrDataset(train_data[0]), batch_size=64, shuffle=True)
val_loader = Data.DrDataLoader(Data.DrDataset(val_data[0]), batch_size=64, shuffle=False)
model = Model.DrModel(CellEncoder.DNN(3, 100), DrugEncoder.MPG(), FusionModule.DNN(100, 768))
result = Model.Train(model, epochs=100, lr=1e-4, train_loader=train_loader, val_loader=val_loader)
data.pair_ls = [[Data.NormalizeName('CAL-12T'), '5-Fluorouracil']]
result = Model.Predict(model=result[0], data=data)
